


let questions = [{
  numb: 1,
  question: "Who is the president of Ghana?",
  answer: "Nana Addo", options: [
    "Nana Addo", 
    "John Mahama", 
    "Paa Kwesi Indum",
    "None of the Above"
  ]
},
{
  numb: 2,
  question: "How do you become a president in Ghana?",
  answer: "by voting",
  options: [
    "by voting",
    "by apointing",
    "by induction",
    "None of the above"
  ]
},
{
  numb: 3,
  question: "What is the type of governanace in Ghana?",
  answer: "democracy",
  options: [
    "democracy",
    "autocracy",
    "timocracy",
    "aristocracy"
  ]
},
{
  numb: 4,
  question: " Business owners who have commercial premises often tend to have residential property as part of their portfolio",
  answer: "True",
  options: [
    "True",
     "False",
    "Cannot tell"
  ]
},
{
  numb: 5,
  question: "What does a dog do to speak?",
  answer: "barks",
  options: [
    "barks",
    "meows",
    "moows",
    "all of the above"
  ]
},
{
  numb: 6,
  question: "how do a cat speak?",
  answer: "meows",
  options: [
    "meows",
    "barks",
    "moows",
    "none of the above"
  ]
},
{
  numb: 7,
  question: "HTML files are saved by default with the extension?",
  answer: ".html",
  options: [
    ".html",
    ".txt",
    ".js",
    ".h"
  ]
},
{
  numb: 8,
  question: "We enclose HTML tags within?",
  answer: "<>",
  options: [
    "<>",
    "{}",
    "()",
    "[]"
  ]
},
{
  numb: 9,
  question: "What was the percentage increase in snowfall in Whistler from November to December?",
  answer: "30%",
  options: [
    "30%",
    "40%",
    "80%",
    "90%"
  ]
},
{
  numb: 10,
  question: "How many revolutions per second is C turning?",
  answer: "40",
  options: [
    "40",
    "30",
    "55",
    "70"
  ]
}
];
